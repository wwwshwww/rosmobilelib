__version__ = '0.1.0'

from .rosclients import MobileClient

__all__ = ['MobileClient']

## EX: 
# import rosmobilelib
# import rosmobilelib.rostools 